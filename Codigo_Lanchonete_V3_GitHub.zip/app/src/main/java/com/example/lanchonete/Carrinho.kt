package com.example.lanchonete

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.lanchonete.data.RepositorioLanchonete
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

data class ItemCarrinho(
    val produto: Produto,
    val quantidade: Int
)

const val TAXA_ENTREGA = 5.00

class EstadoCarrinho(
    private val repositorio: RepositorioLanchonete,
    private val scope: CoroutineScope
) {
    val itens = mutableStateListOf<ItemCarrinho>()

    var ultimoProdutoAdicionado by mutableStateOf<String?>(null)
        private set

    var eventoAdicao by mutableIntStateOf(0)
        private set

    val quantidadeTotal: Int
        get() = itens.sumOf { it.quantidade }

    val subtotal: Double
        get() = itens.sumOf {
            it.produto.preco * it.quantidade
        }

    val total: Double
        get() = if (itens.isEmpty()) 0.0 else subtotal + TAXA_ENTREGA

    // Atualiza a interface com os dados lidos do banco.
    fun atualizarPeloBanco(novosItens: List<ItemCarrinho>) {
        itens.clear()
        itens.addAll(novosItens)
    }

    fun adicionar(produto: Produto, quantidade: Int = 1) {
        scope.launch {
            if (repositorio.adicionarAoCarrinho(produto.id, quantidade)) {
                ultimoProdutoAdicionado = produto.nome
                eventoAdicao++
            }
        }
    }

    fun diminuir(produto: Produto) {
        scope.launch {
            repositorio.diminuirNoCarrinho(produto.id)
        }
    }

    fun limpar() {
        scope.launch {
            repositorio.limparCarrinho()
        }
    }
}
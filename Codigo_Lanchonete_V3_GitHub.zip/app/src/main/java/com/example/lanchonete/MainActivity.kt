package com.example.lanchonete

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import com.example.lanchonete.data.RepositorioLanchonete
import com.example.lanchonete.ui.theme.LanchoneteTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LanchoneteTheme {
                AppLanchonete()
            }
        }
    }
}

data class ItemMenu(
    val rotulo: String,
    val icone: ImageVector
)

enum class EtapaCheckout {
    NENHUMA,
    ENDERECO,
    PAGAMENTO,
    CONFIRMACAO
}

val itensMenu = listOf(
    ItemMenu("Início", Icons.Filled.Home),
    ItemMenu("Cardápio", Icons.Filled.RestaurantMenu),
    ItemMenu("Carrinho", Icons.Filled.ShoppingCart),
    ItemMenu("Gerenciar", Icons.Filled.EditNote)
)

@Composable
fun AppLanchonete() {

    val contexto = LocalContext.current.applicationContext

    val repositorio = remember(contexto) {
        RepositorioLanchonete(contexto)
    }

    val scope = rememberCoroutineScope()

    val carrinho = remember(repositorio, scope) {
        EstadoCarrinho(repositorio, scope)
    }

    val snackbarHostState = remember {
        SnackbarHostState()
    }

    var produtos by remember {
        mutableStateOf<List<Produto>>(emptyList())
    }

    var carregando by remember {
        mutableStateOf(true)
    }

    var abaSelecionada by remember {
        mutableIntStateOf(0)
    }

    var etapaCheckout by remember {
        mutableStateOf(EtapaCheckout.NENHUMA)
    }

    var enderecoSelecionado by remember {
        mutableStateOf("")
    }

    var formaPagamentoSelecionada by remember {
        mutableStateOf("")
    }

    var totalPedidoConfirmado by remember {
        mutableStateOf(0.0)
    }

    // Busca os produtos no banco Room.
    LaunchedEffect(repositorio) {

        repositorio.inicializarSeNecessario()

        repositorio.observarProdutos().collect { lista ->
            produtos = lista
            carregando = false
        }
    }

    // Atualiza o carrinho conforme os dados do banco.
    LaunchedEffect(repositorio, carrinho) {

        repositorio.observarItensCarrinho().collect {
            carrinho.atualizarPeloBanco(it)
        }
    }

    // Exibe mensagem após adicionar ao carrinho.
    LaunchedEffect(carrinho.eventoAdicao) {

        if (carrinho.eventoAdicao > 0) {

            snackbarHostState.showSnackbar(
                "${carrinho.ultimoProdutoAdicionado ?: "Produto"} adicionado ao carrinho!"
            )
        }
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        },

        bottomBar = {

            if (etapaCheckout == EtapaCheckout.NENHUMA) {

                NavigationBar {

                    itensMenu.forEachIndexed { indice, item ->

                        NavigationBarItem(
                            selected = abaSelecionada == indice,

                            onClick = {
                                abaSelecionada = indice
                            },

                            icon = {

                                if (indice == 2) {

                                    BadgedBox(
                                        badge = {

                                            if (carrinho.quantidadeTotal > 0) {
                                                Badge {
                                                    Text(
                                                        carrinho.quantidadeTotal.toString()
                                                    )
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            item.icone,
                                            contentDescription = item.rotulo
                                        )
                                    }

                                } else {

                                    Icon(
                                        item.icone,
                                        contentDescription = item.rotulo
                                    )
                                }
                            },

                            label = {
                                Text(item.rotulo)
                            }
                        )
                    }
                }
            }
        }
    ) { espacamento ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(espacamento)
        ) {

            if (carregando) {

                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center)
                )

            } else {

                when (etapaCheckout) {

                    EtapaCheckout.NENHUMA -> {

                        when (abaSelecionada) {

                            0 -> TelaInicial(
                                carrinho = carrinho,
                                produtos = produtos
                            )

                            1 -> TelaCardapio(
                                carrinho = carrinho,
                                produtos = produtos,
                                repositorio = repositorio,
                                aoVoltar = {
                                    abaSelecionada = 0
                                }
                            )

                            2 -> TelaCarrinho(
                                carrinho = carrinho,
                                aoFinalizarPedido = {
                                    etapaCheckout = EtapaCheckout.ENDERECO
                                },
                                aoVoltar = {
                                    abaSelecionada = 1
                                }
                            )

                            else -> TelaGerenciarProdutos(
                                produtos = produtos,

                                aoSalvar = { produto ->

                                    scope.launch {

                                        repositorio.salvarProduto(produto)

                                        snackbarHostState.showSnackbar(
                                            "Produto salvo no banco!"
                                        )
                                    }
                                },

                                aoExcluir = { produto ->

                                    scope.launch {

                                        repositorio.excluirProduto(produto)

                                        snackbarHostState.showSnackbar(
                                            "Produto excluído do banco!"
                                        )
                                    }
                                }
                            )
                        }
                    }

                    EtapaCheckout.ENDERECO -> TelaEndereco(
                        aoVoltar = {
                            etapaCheckout = EtapaCheckout.NENHUMA
                        },

                        aoConfirmar = {
                                rua, numero, complemento, bairro, cidade, cep ->

                            enderecoSelecionado =
                                if (complemento.isBlank()) {
                                    "$rua, $numero - $bairro, $cidade - CEP $cep"
                                } else {
                                    "$rua, $numero - $complemento - $bairro, $cidade - CEP $cep"
                                }

                            etapaCheckout = EtapaCheckout.PAGAMENTO
                        }
                    )

                    EtapaCheckout.PAGAMENTO -> TelaPagamento(
                        total = carrinho.total,
                        endereco = enderecoSelecionado,

                        aoVoltar = {
                            etapaCheckout = EtapaCheckout.ENDERECO
                        },

                        aoConfirmar = { formaPagamento ->

                            formaPagamentoSelecionada = formaPagamento

                            totalPedidoConfirmado = carrinho.total

                            etapaCheckout = EtapaCheckout.CONFIRMACAO
                        }
                    )

                    EtapaCheckout.CONFIRMACAO -> TelaConfirmacaoPedido(
                        total = totalPedidoConfirmado,
                        endereco = enderecoSelecionado,
                        formaPagamento = formaPagamentoSelecionada,

                        aoVoltarInicio = {

                            carrinho.limpar()

                            abaSelecionada = 0

                            etapaCheckout = EtapaCheckout.NENHUMA

                            enderecoSelecionado = ""

                            formaPagamentoSelecionada = ""

                            totalPedidoConfirmado = 0.0
                        }
                    )
                }
            }
        }
    }
}
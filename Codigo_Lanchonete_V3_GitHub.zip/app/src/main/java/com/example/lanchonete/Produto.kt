package com.example.lanchonete

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Icecream
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.LunchDining
import androidx.compose.ui.graphics.vector.ImageVector

data class Produto(
    val id: Int,
    val nome: String,
    val descricao: String,
    val preco: Double,
    val categoria: String
)

val categorias = listOf(
    "Lanches",
    "Acompanhamentos",
    "Bebidas",
    "Sobremesas"
)

// Produtos cadastrados apenas na primeira execução.
val produtosIniciais = listOf(
    Produto(
        id = 1,
        nome = "X-Burger",
        descricao = "Pão, carne, queijo, alface, tomate, cebola e molho especial.",
        preco = 18.00,
        categoria = "Lanches"
    ),
    Produto(
        id = 2,
        nome = "X-Bacon",
        descricao = "Pão, carne, queijo, bacon crocante e molho barbecue.",
        preco = 35.00,
        categoria = "Lanches"
    ),
    Produto(
        id = 3,
        nome = "X-Salada",
        descricao = "Pão, carne, queijo, alface, tomate e maionese.",
        preco = 17.00,
        categoria = "Lanches"
    ),
    Produto(
        id = 4,
        nome = "Batata Frita",
        descricao = "Porção de batatas fritas crocantes com sal.",
        preco = 8.00,
        categoria = "Acompanhamentos"
    ),
    Produto(
        id = 5,
        nome = "Anéis de Cebola",
        descricao = "Porção de cebolas empanadas e fritas.",
        preco = 9.00,
        categoria = "Acompanhamentos"
    ),
    Produto(
        id = 6,
        nome = "Refrigerante",
        descricao = "Lata de 350ml gelada.",
        preco = 6.00,
        categoria = "Bebidas"
    ),
    Produto(
        id = 7,
        nome = "Suco Natural",
        descricao = "Copo de 500ml, laranja ou maracujá.",
        preco = 7.00,
        categoria = "Bebidas"
    ),
    Produto(
        id = 8,
        nome = "Milkshake",
        descricao = "Copo de 400ml, chocolate ou morango.",
        preco = 12.00,
        categoria = "Sobremesas"
    )
)

fun iconeDaCategoria(categoria: String): ImageVector {
    return when (categoria) {
        "Lanches" -> Icons.Filled.LunchDining
        "Acompanhamentos" -> Icons.Filled.Fastfood
        "Bebidas" -> Icons.Filled.LocalDrink
        else -> Icons.Filled.Icecream
    }
}

fun formatarPreco(valor: Double): String {
    return "R$ " + String.format("%.2f", valor).replace(".", ",")
}
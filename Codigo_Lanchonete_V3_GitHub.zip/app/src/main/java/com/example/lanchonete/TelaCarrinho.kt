package com.example.lanchonete

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TelaCarrinho(
    carrinho: EstadoCarrinho,
    aoFinalizarPedido: () -> Unit,
    aoVoltar: () -> Unit
) {

    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        BarraTopoCarrinho(
            aoVoltar = aoVoltar,
            aoLimpar = {
                carrinho.limpar()
            }
        )

        if (carrinho.itens.isEmpty()) {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),

                contentAlignment = Alignment.Center
            ) {

                Text(
                    text = "Seu carrinho está vazio",
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }

        } else {

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {

                items(
                    items = carrinho.itens,
                    key = {
                        it.produto.id
                    }
                ) { item ->

                    LinhaCarrinho(
                        item = item,

                        aoAumentar = {
                            carrinho.adicionar(item.produto)
                        },

                        aoDiminuir = {
                            carrinho.diminuir(item.produto)
                        }
                    )
                }
            }

            ResumoPedido(
                subtotal = carrinho.subtotal,
                total = carrinho.total,
                aoFinalizarPedido = aoFinalizarPedido
            )
        }
    }
}

@Composable
private fun BarraTopoCarrinho(
    aoVoltar: () -> Unit,
    aoLimpar: () -> Unit
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = 16.dp,
                vertical = 8.dp
            ),

        horizontalArrangement = Arrangement.SpaceBetween,

        verticalAlignment = Alignment.CenterVertically
    ) {

        IconButton(
            onClick = aoVoltar
        ) {

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar"
            )
        }

        Text(
            text = "Meu Carrinho",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        IconButton(
            onClick = aoLimpar
        ) {

            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = "Esvaziar carrinho"
            )
        }
    }
}

@Composable
private fun LinhaCarrinho(
    item: ItemCarrinho,
    aoAumentar: () -> Unit,
    aoDiminuir: () -> Unit
) {

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),

            verticalAlignment = Alignment.CenterVertically,

            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            Icon(
                imageVector = iconeDaCategoria(item.produto.categoria),
                contentDescription = null,
                modifier = Modifier.size(36.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = item.produto.nome,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Text(
                    text = formatarPreco(
                        item.produto.preco * item.quantidade
                    ),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            SeletorQuantidade(
                quantidade = item.quantidade,
                aoAumentar = aoAumentar,
                aoDiminuir = aoDiminuir
            )
        }
    }
}

@Composable
private fun SeletorQuantidade(
    quantidade: Int,
    aoAumentar: () -> Unit,
    aoDiminuir: () -> Unit
) {

    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {

        IconButton(
            onClick = aoDiminuir,
            modifier = Modifier.size(28.dp)
        ) {

            Icon(
                imageVector = Icons.Filled.Remove,
                contentDescription = "Diminuir",
                modifier = Modifier.size(16.dp)
            )
        }

        Text(
            text = quantidade.toString(),
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 10.dp)
        )

        IconButton(
            onClick = aoAumentar,
            modifier = Modifier.size(28.dp)
        ) {

            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Aumentar",
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun ResumoPedido(
    subtotal: Double,
    total: Double,
    aoFinalizarPedido: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {

        LinhaValor(
            rotulo = "Subtotal",
            valor = formatarPreco(subtotal)
        )

        LinhaValor(
            rotulo = "Taxa de entrega",
            valor = formatarPreco(TAXA_ENTREGA)
        )

        HorizontalDivider()

        LinhaValor(
            rotulo = "Total",
            valor = formatarPreco(total),
            destaque = true
        )

        Button(
            onClick = aoFinalizarPedido,

            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        ) {

            Text("Finalizar pedido")
        }
    }
}

@Composable
private fun LinhaValor(
    rotulo: String,
    valor: String,
    destaque: Boolean = false
) {

    Row(
        modifier = Modifier.fillMaxWidth(),

        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Text(
            text = rotulo,

            fontSize = if (destaque) 16.sp else 14.sp,

            fontWeight = if (destaque) {
                FontWeight.Bold
            } else {
                FontWeight.Normal
            }
        )

        Text(
            text = valor,

            fontSize = if (destaque) 16.sp else 14.sp,

            fontWeight = if (destaque) {
                FontWeight.Bold
            } else {
                FontWeight.Normal
            }
        )
    }
}
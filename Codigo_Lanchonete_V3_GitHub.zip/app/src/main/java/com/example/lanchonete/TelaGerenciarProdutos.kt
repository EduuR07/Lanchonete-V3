
package com.example.lanchonete

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun TelaGerenciarProdutos(
    produtos: List<Produto>,
    aoSalvar: (Produto) -> Unit,
    aoExcluir: (Produto) -> Unit
) {
    var mostrarFormulario by remember {
        mutableStateOf(false)
    }

    var produtoEmEdicao by remember {
        mutableStateOf<Produto?>(null)
    }

    var produtoParaExcluir by remember {
        mutableStateOf<Produto?>(null)
    }

    var nome by remember { mutableStateOf("") }
    var descricao by remember { mutableStateOf("") }
    var preco by remember { mutableStateOf("") }

    var categoria by remember {
        mutableStateOf(categorias.first())
    }

    var erro by remember {
        mutableStateOf<String?>(null)
    }

    // Abre o formulário para cadastrar ou editar.
    fun abrirFormulario(produto: Produto?) {
        produtoEmEdicao = produto
        nome = produto?.nome ?: ""
        descricao = produto?.descricao ?: ""

        preco = produto?.preco
            ?.toString()
            ?.replace(".", ",") ?: ""

        categoria = produto?.categoria ?: categorias.first()
        erro = null
        mostrarFormulario = true
    }

    // Tela principal: lista de produtos com rolagem.
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text(
            text = "Gerenciar cardápio",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp)
        )

        Text(
            text = "Gerencie os produtos armazenados no Room.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { abrirFormulario(null) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = null
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text("Cadastrar novo produto")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Produtos cadastrados (${produtos.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 12.dp)
        )

        // A lista ocupa o espaço restante da tela.
        // Somente esta região precisa rolar.
        if (produtos.isEmpty()) {

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Nenhum produto cadastrado.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

        } else {

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),

                contentPadding = PaddingValues(bottom = 24.dp),

                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {

                items(
                    items = produtos,
                    key = { it.id }
                ) { produto ->

                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),

                            verticalAlignment = Alignment.CenterVertically,

                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {

                            Icon(
                                imageVector = iconeDaCategoria(
                                    produto.categoria
                                ),
                                contentDescription = null,
                                modifier = Modifier.size(30.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {

                                Text(
                                    text = produto.nome,
                                    fontWeight = FontWeight.SemiBold
                                )

                                Text(
                                    text = "ID ${produto.id} - ${produto.categoria}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Text(
                                    text = formatarPreco(produto.preco),
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            IconButton(
                                onClick = {
                                    abrirFormulario(produto)
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Editar ${produto.nome}"
                                )
                            }

                            IconButton(
                                onClick = {
                                    produtoParaExcluir = produto
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Excluir ${produto.nome}",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Formulário de cadastro e edição.
    if (mostrarFormulario) {

        AlertDialog(
            onDismissRequest = {
                mostrarFormulario = false
            },

            title = {
                Text(
                    if (produtoEmEdicao == null) {
                        "Cadastrar produto"
                    } else {
                        "Editar produto"
                    }
                )
            },

            text = {

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),

                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {

                    OutlinedTextField(
                        value = nome,
                        onValueChange = { nome = it },
                        label = { Text("Nome") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = descricao,
                        onValueChange = { descricao = it },
                        label = { Text("Descrição") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = preco,
                        onValueChange = { preco = it },
                        label = { Text("Preço (ex.: 19,90)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Categoria",
                        style = MaterialTheme.typography.labelLarge
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),

                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {

                        categorias.forEach { opcao ->

                            FilterChip(
                                selected = categoria == opcao,
                                onClick = { categoria = opcao },
                                label = { Text(opcao) }
                            )
                        }
                    }

                    erro?.let { mensagem ->

                        Text(
                            text = mensagem,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },

            confirmButton = {

                TextButton(
                    onClick = {

                        val precoConvertido = preco
                            .trim()
                            .replace(",", ".")
                            .toDoubleOrNull()

                        erro = when {

                            nome.isBlank() ->
                                "Informe o nome do produto."

                            descricao.isBlank() ->
                                "Informe a descrição."

                            precoConvertido == null ||
                                    !precoConvertido.isFinite() ||
                                    precoConvertido <= 0.0 ->
                                "Informe um preço válido maior que zero."

                            else -> null
                        }

                        if (erro == null && precoConvertido != null) {

                            val produto = Produto(
                                id = produtoEmEdicao?.id ?: 0,
                                nome = nome.trim(),
                                descricao = descricao.trim(),
                                preco = precoConvertido,
                                categoria = categoria
                            )

                            aoSalvar(produto)

                            mostrarFormulario = false
                            produtoEmEdicao = null
                        }
                    }
                ) {

                    Text(
                        if (produtoEmEdicao == null) {
                            "Cadastrar"
                        } else {
                            "Salvar"
                        }
                    )
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        mostrarFormulario = false
                        produtoEmEdicao = null
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Confirmação antes de excluir do banco.
    produtoParaExcluir?.let { produto ->

        AlertDialog(
            onDismissRequest = {
                produtoParaExcluir = null
            },

            title = {
                Text("Excluir produto?")
            },

            text = {
                Text(
                    "Deseja excluir '${produto.nome}' permanentemente do banco de dados?"
                )
            },

            confirmButton = {

                TextButton(
                    onClick = {

                        aoExcluir(produto)

                        produtoParaExcluir = null
                    }
                ) {
                    Text(
                        text = "Excluir",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },

            dismissButton = {

                TextButton(
                    onClick = {
                        produtoParaExcluir = null
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }
}

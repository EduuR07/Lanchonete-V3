package com.example.lanchonete.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProdutoEntity::class,
        ItemCarrinhoEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun produtoDao(): ProdutoDao

    abstract fun itemCarrinhoDao(): ItemCarrinhoDao

    companion object {

        @Volatile
        private var instancia: AppDatabase? = null

        fun obterInstancia(context: Context): AppDatabase =
            instancia ?: synchronized(this) {

                instancia ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lanchonete_v3.db"
                ).build().also {
                    instancia = it
                }
            }
    }
}
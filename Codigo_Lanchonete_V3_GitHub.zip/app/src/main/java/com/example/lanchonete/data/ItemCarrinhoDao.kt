package com.example.lanchonete.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemCarrinhoDao {

    @Query("SELECT * FROM itens_carrinho ORDER BY produtoId ASC")
    fun observarTodos(): Flow<List<ItemCarrinhoEntity>>

    @Query("SELECT * FROM itens_carrinho ORDER BY produtoId ASC")
    suspend fun buscarTodos(): List<ItemCarrinhoEntity>

    @Query("SELECT * FROM itens_carrinho WHERE produtoId = :produtoId LIMIT 1")
    suspend fun buscarPorId(produtoId: Int): ItemCarrinhoEntity?

    @Insert
    suspend fun inserir(item: ItemCarrinhoEntity): Long

    @Update
    suspend fun atualizar(item: ItemCarrinhoEntity): Int

    @Delete
    suspend fun deletar(item: ItemCarrinhoEntity): Int

    @Query("DELETE FROM itens_carrinho")
    suspend fun limpar()
}
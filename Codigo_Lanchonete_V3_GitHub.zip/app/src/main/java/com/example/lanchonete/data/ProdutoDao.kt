package com.example.lanchonete.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProdutoDao {

    @Query("SELECT * FROM produtos ORDER BY id ASC")
    fun observarTodos(): Flow<List<ProdutoEntity>>

    @Query("SELECT * FROM produtos ORDER BY id ASC")
    suspend fun buscarTodos(): List<ProdutoEntity>

    @Query("SELECT * FROM produtos WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): ProdutoEntity?

    @Query("SELECT * FROM produtos WHERE id = :id LIMIT 1")
    fun observarPorId(id: Int): Flow<ProdutoEntity?>

    @Query("SELECT COUNT(*) FROM produtos")
    suspend fun contar(): Int

    @Insert
    suspend fun inserir(produto: ProdutoEntity): Long

    @Update
    suspend fun atualizar(produto: ProdutoEntity): Int

    @Delete
    suspend fun deletar(produto: ProdutoEntity): Int
}
package com.example.lanchonete.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.lanchonete.Produto

@Entity(tableName = "produtos")
data class ProdutoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nome: String,
    val descricao: String,
    val preco: Double,
    val categoria: String
)

fun ProdutoEntity.paraProduto() = Produto(
    id = id,
    nome = nome,
    descricao = descricao,
    preco = preco,
    categoria = categoria
)

fun Produto.paraEntity() = ProdutoEntity(
    id = id,
    nome = nome,
    descricao = descricao,
    preco = preco,
    categoria = categoria
)
package com.example.lanchonete.data

import android.content.Context
import androidx.room.withTransaction
import com.example.lanchonete.ItemCarrinho
import com.example.lanchonete.Produto
import com.example.lanchonete.produtosIniciais
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

class RepositorioLanchonete(context: Context) {

    private val banco = AppDatabase.obterInstancia(context)

    private val produtoDao = banco.produtoDao()

    private val carrinhoDao = banco.itemCarrinhoDao()

    private val preferencias =
        context.applicationContext.getSharedPreferences(
            "configuracoes_lanchonete_v3",
            Context.MODE_PRIVATE
        )

    fun observarProdutos(): Flow<List<Produto>> =
        produtoDao.observarTodos()
            .map { lista ->
                lista.map { it.paraProduto() }
            }
            .flowOn(Dispatchers.IO)

    fun observarProdutoPorId(id: Int): Flow<Produto?> =
        produtoDao.observarPorId(id)
            .map { it?.paraProduto() }
            .flowOn(Dispatchers.IO)

    fun observarItensCarrinho(): Flow<List<ItemCarrinho>> =
        combine(
            produtoDao.observarTodos(),
            carrinhoDao.observarTodos()
        ) { produtos, itens ->

            val produtosPorId = produtos.associateBy { it.id }

            itens.mapNotNull { item ->
                produtosPorId[item.produtoId]?.let { produto ->
                    ItemCarrinho(
                        produto = produto.paraProduto(),
                        quantidade = item.quantidade
                    )
                }
            }
        }.flowOn(Dispatchers.IO)

    // Cadastra os produtos iniciais apenas uma vez.
    suspend fun inicializarSeNecessario() =
        withContext(Dispatchers.IO) {

            if (!preferencias.getBoolean("cardapio_inicializado", false)) {

                banco.withTransaction {

                    if (produtoDao.contar() == 0) {
                        produtosIniciais.forEach { produto ->
                            produtoDao.inserir(produto.paraEntity())
                        }
                    }
                }

                preferencias.edit()
                    .putBoolean("cardapio_inicializado", true)
                    .commit()
            }
        }

    suspend fun salvarProduto(produto: Produto) =
        withContext(Dispatchers.IO) {

            if (produto.id == 0) {
                produtoDao.inserir(produto.paraEntity())
            } else {
                produtoDao.atualizar(produto.paraEntity())
            }
        }

    suspend fun excluirProduto(produto: Produto) =
        withContext(Dispatchers.IO) {
            produtoDao.deletar(produto.paraEntity())
        }

    suspend fun adicionarAoCarrinho(
        produtoId: Int,
        quantidade: Int = 1
    ): Boolean = withContext(Dispatchers.IO) {

        if (quantidade <= 0) {
            return@withContext false
        }

        banco.withTransaction {

            if (produtoDao.buscarPorId(produtoId) == null) {
                return@withTransaction false
            }

            val existente = carrinhoDao.buscarPorId(produtoId)

            if (existente == null) {
                carrinhoDao.inserir(
                    ItemCarrinhoEntity(
                        produtoId = produtoId,
                        quantidade = quantidade
                    )
                )
            } else {
                carrinhoDao.atualizar(
                    existente.copy(
                        quantidade = existente.quantidade + quantidade
                    )
                )
            }

            true
        }
    }

    suspend fun diminuirNoCarrinho(produtoId: Int) =
        withContext(Dispatchers.IO) {

            banco.withTransaction {

                val item = carrinhoDao.buscarPorId(produtoId)
                    ?: return@withTransaction

                if (item.quantidade <= 1) {
                    carrinhoDao.deletar(item)
                } else {
                    carrinhoDao.atualizar(
                        item.copy(
                            quantidade = item.quantidade - 1
                        )
                    )
                }
            }
        }

    suspend fun limparCarrinho() =
        withContext(Dispatchers.IO) {
            carrinhoDao.limpar()
        }
}
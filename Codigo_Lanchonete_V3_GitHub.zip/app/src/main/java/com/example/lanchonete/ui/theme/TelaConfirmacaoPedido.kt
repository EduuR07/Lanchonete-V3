package com.example.lanchonete

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TelaConfirmacaoPedido(
    total: Double,
    endereco: String,
    formaPagamento: String,
    aoVoltarInicio: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.spacedBy(18.dp)
    ) {

        Spacer(
            modifier =
                Modifier.height(24.dp)
        )

        /*
         * ÍCONE DE SUCESSO
         */
        Icon(
            imageVector =
                Icons.Filled.CheckCircle,

            contentDescription =
                "Pedido confirmado",

            modifier =
                Modifier.size(90.dp),

            tint =
                MaterialTheme
                    .colorScheme
                    .primary
        )

        /*
         * TÍTULO
         */
        Text(
            text =
                "Pedido confirmado!",

            fontSize = 26.sp,

            fontWeight =
                FontWeight.Bold,

            textAlign =
                TextAlign.Center
        )

        Text(
            text =
                "Seu pedido foi recebido com sucesso e já está sendo preparado.",

            fontSize = 15.sp,

            textAlign =
                TextAlign.Center,

            color =
                MaterialTheme
                    .colorScheme
                    .outline
        )

        /*
         * CARD COM DADOS DO PEDIDO
         */
        Card(
            modifier =
                Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),

                verticalArrangement =
                    Arrangement.spacedBy(16.dp)
            ) {

                Text(
                    text =
                        "Resumo do pedido",

                    fontSize = 18.sp,

                    fontWeight =
                        FontWeight.Bold
                )

                HorizontalDivider()

                /*
                 * PAGAMENTO
                 */
                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.spacedBy(12.dp),

                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector =
                            Icons.Filled.Payments,

                        contentDescription = null,

                        tint =
                            MaterialTheme
                                .colorScheme
                                .primary
                    )

                    Column {

                        Text(
                            text =
                                "Forma de pagamento",

                            fontSize = 13.sp,

                            color =
                                MaterialTheme
                                    .colorScheme
                                    .outline
                        )

                        Text(
                            text =
                                formaPagamento,

                            fontSize = 15.sp,

                            fontWeight =
                                FontWeight.SemiBold
                        )
                    }
                }

                /*
                 * ENDEREÇO
                 */
                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.spacedBy(12.dp),

                    verticalAlignment =
                        Alignment.Top
                ) {

                    Icon(
                        imageVector =
                            Icons.Filled.LocationOn,

                        contentDescription = null,

                        tint =
                            MaterialTheme
                                .colorScheme
                                .primary
                    )

                    Column(
                        modifier =
                            Modifier.weight(1f)
                    ) {

                        Text(
                            text =
                                "Endereço de entrega",

                            fontSize = 13.sp,

                            color =
                                MaterialTheme
                                    .colorScheme
                                    .outline
                        )

                        Text(
                            text =
                                endereco,

                            fontSize = 15.sp,

                            fontWeight =
                                FontWeight.SemiBold
                        )
                    }
                }

                HorizontalDivider()

                /*
                 * TOTAL
                 */
                Row(
                    modifier =
                        Modifier.fillMaxWidth(),

                    horizontalArrangement =
                        Arrangement.SpaceBetween,

                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Text(
                        text =
                            "Total pago",

                        fontSize = 17.sp,

                        fontWeight =
                            FontWeight.Bold
                    )

                    Text(
                        text =
                            formatarPreco(total),

                        fontSize = 20.sp,

                        fontWeight =
                            FontWeight.Bold,

                        color =
                            MaterialTheme
                                .colorScheme
                                .primary
                    )
                }
            }
        }

        /*
         * STATUS
         */
        Text(
            text =
                "Acompanhe seu pedido enquanto preparamos tudo para a entrega.",

            fontSize = 14.sp,

            textAlign =
                TextAlign.Center,

            color =
                MaterialTheme
                    .colorScheme
                    .outline
        )

        Spacer(
            modifier =
                Modifier.weight(1f)
        )

        /*
         * BOTÃO FINAL
         */
        Button(
            onClick =
                aoVoltarInicio,

            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {

            Icon(
                imageVector =
                    Icons.Filled.Home,

                contentDescription =
                    null
            )

            Text(
                text =
                    "  Voltar para o início"
            )
        }
    }
}